import React from 'react'

const CreditNoteInventoryRMA = () => {
    return (
        <div>
            CreditNoteInventoryRMA
        </div>
    )
}

export default CreditNoteInventoryRMA
